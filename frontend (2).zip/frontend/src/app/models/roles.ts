export interface Roles{
  id: number;
  roleName: String;
}
