export interface BaseEntity{
  createdAt: Date;
  createdBy: String;
  updatedAt: Date;
  updatedBy: String;
}
