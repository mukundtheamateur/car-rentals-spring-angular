package com.cts.thundercars.controllers;

import com.cts.thundercars.entity.User;
import com.cts.thundercars.exceptions.AlreadyExistsException;
import com.cts.thundercars.exceptions.NoUserFoundException;
import com.cts.thundercars.exceptions.NotFoundException;
import com.cts.thundercars.exceptions.RoleIdNotFoundException;
import com.cts.thundercars.services.UserServices;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserServices userServices;

    @Autowired
    public UserController(UserServices userServices) {
        this.userServices = userServices;
    }

    @GetMapping(value= {"", "/"})
    public ResponseEntity<List<User>> getAllUsers() {
        return new ResponseEntity<>(userServices.getUsers(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Integer id) throws NotFoundException {
        User user =userServices.getUserById(id);
        return new ResponseEntity<>(user,HttpStatus.OK);
    }

    @PostMapping(value= "/create")
    public ResponseEntity<User> createUser(@RequestBody User user) throws AlreadyExistsException {
        User updatedUser= userServices.saveUser(user);
        return new ResponseEntity<>(updatedUser, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Integer id) throws NotFoundException {
        userServices.deleteUser(id);
        return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<User> getUserByEmail(@PathVariable String email) throws NotFoundException {
        return new ResponseEntity<>(userServices.getUserByEmail(email), HttpStatus.OK);
    }
    
    @PutMapping("/update/{id}")
    public User updateUser(@PathVariable Integer id, @RequestBody User userUpdates) throws NotFoundException, RoleIdNotFoundException {
        return userServices.updateUser(id, userUpdates);
    }

    @GetMapping("/role/{role}")
    public List<User> getUsersByRoleId(@PathVariable Integer role) throws NoUserFoundException {
        return userServices.getUsersByRoleId(role);
    }
}
