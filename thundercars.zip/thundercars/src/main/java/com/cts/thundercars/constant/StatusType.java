package com.cts.thundercars.constant;

public enum StatusType {
	PAID, UNPAID, RESERVED, VOID, CANCELLED
}
