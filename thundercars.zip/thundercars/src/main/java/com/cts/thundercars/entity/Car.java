package com.cts.thundercars.entity;


import com.cts.thundercars.constant.FuelPolicyType;
import com.cts.thundercars.constant.FuelType;
import com.cts.thundercars.constant.GearBoxType;
import com.cts.thundercars.constant.WheelDriveType;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "car")
public class Car extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank(message="car name can not be blank")
    @Column(name = "car_name", nullable = false)
    private String carName;

    @NotBlank(message="dealer id can not be blank")
    @Column(name = "dealer_id", nullable = false)
    private Integer dealerId;

    @NotBlank(message="price can not be blank")
    @Column(name = "price", nullable = false)
    private Integer price;

    @NotBlank(message="deposit can not be blank")
    @Column(name = "deposit", nullable = false)
    private Integer deposit;

    @NotBlank(message="fuel type can not be blank")
    @Enumerated(EnumType.STRING)
    @Column(name = "fuel_type", nullable = false)
    private FuelType fuelType;

    @NotBlank(message="gearbox can not be blank")
    @Enumerated(EnumType.STRING)
    @Column(name = "gearbox", nullable=false)
    private GearBoxType gearbox;

    @NotBlank(message="car image can not be blank")
    @Column(name = "image", nullable = false)
    private String image;

    @NotBlank(message="seats can not be blank")
    @Column(name = "seats", nullable = false)
    private Integer seats;

    @NotBlank(message="doors can not be blank")
    @Column(name = "doors", nullable = false)
    private Integer doors;
    
    @NotBlank(message="FuelPolicy can not be blank")
    @Enumerated(EnumType.STRING)
    @Column(name = "fuelpolicy", nullable=false)
    private FuelPolicyType fuelpolicy;

	@Column(name = "mileage")
    private Integer mileage;
	
	@NotBlank(message="Cancellation price can not be blank")
    @Column(name = "cancellation", nullable = false)
    private Integer cancellation;

    @Column(name = "amendments")
    private Integer amendments;

    @NotBlank(message="theftProtection charges can not be blank")
    @Column(name = "theft_protection", nullable = false)
    private Integer theftProtection;

    @NotBlank(message="collisionDamage charges can not be blank")
    @Column(name = "collision_damage", nullable = false)
    private Integer collisionDamage;

    @NotBlank(message="fullInsurance price can not be blank")
    @Column(name = "full_insurance", nullable = false)
    private Integer fullInsurance;

    @NotBlank(message="AdditionalDriver charges can not be blank")
    @Column(name = "additional_driver", nullable = false)
    private Integer additionalDriver;
    
    @NotBlank(message="WheelDrive type can not be blank")
    @Enumerated(EnumType.STRING)
    @Column(name = "wheel_drive", nullable=false)
    private WheelDriveType wheelDrive;
   
    @OneToOne
    @JoinColumn(name = "dealer_id",referencedColumnName="id", insertable=false, updatable=false, nullable = false)
    private CarDealer dealer; 
}


