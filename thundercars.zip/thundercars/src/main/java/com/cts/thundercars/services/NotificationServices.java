package com.cts.thundercars.services;

import java.util.List;
import java.util.Optional;
import com.cts.thundercars.entity.Notification;

public interface NotificationServices {
    Notification createNotification(Notification notification);
    Optional<Notification> getNotificationById(Integer id);
    List<Notification> getAllNotifications();
    Notification updateNotification(Notification notification);
    void deleteNotification(Integer id);
    List<Notification> getNotificationsByUserId(Integer userId);
    List<Notification> getUnreadNotificationsByUserId(Integer userId);
}
