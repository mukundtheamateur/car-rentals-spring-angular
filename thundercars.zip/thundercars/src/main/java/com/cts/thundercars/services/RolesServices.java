package com.cts.thundercars.services;

import java.util.List;
import java.util.Optional;

import com.cts.thundercars.entity.Roles;


public interface RolesServices {
    List<Roles> getAllRoles();
    Optional<Roles> getRolesById(Integer id);
    Roles saveRole(Roles role);
    void deleteRole(Integer id);
    Optional<Roles> getRolesByName(String roleName);
}

