package com.cts.thundercars.services;

import com.cts.thundercars.entity.Bookings;
import java.util.List;
import java.util.Optional;

public interface BookingsServices {
    List<Bookings> getAllBookings();
    Optional<Bookings> getBookingById(Integer id);
    Bookings saveBooking(Bookings booking);
    void deleteBooking(Integer id);
    List<Bookings> getBookingsByUserId(Integer userId);
    List<Bookings> getBookingsByCarId(Integer carId);
}

