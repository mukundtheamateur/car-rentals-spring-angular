package com.cts.thundercars.exceptions;

@SuppressWarnings("serial")
public class NotFoundException extends Exception {

	public NotFoundException(String message) {
		super(message);
	}
}
