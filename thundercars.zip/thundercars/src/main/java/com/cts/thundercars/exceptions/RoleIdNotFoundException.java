package com.cts.thundercars.exceptions;

@SuppressWarnings("serial")
public class RoleIdNotFoundException extends Exception {

	public RoleIdNotFoundException(String message) {
		super(message);
	}
}
