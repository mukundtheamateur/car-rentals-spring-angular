package com.cts.thundercars.constant;

public enum WheelDriveType {
	FWD,
	RWD,
	FourWD,
	AWD
}
