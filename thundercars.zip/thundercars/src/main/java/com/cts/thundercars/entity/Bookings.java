package com.cts.thundercars.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

import com.cts.thundercars.constant.StatusType;

@Entity
@Table(name = "bookings")
@Data
@EqualsAndHashCode(callSuper = true)
public class Bookings extends BaseEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", insertable=false, updatable=false)
    private Integer id;

    @NotNull(message="From date should not be null")
    @Column(name = "from_date", nullable = false)
    private Date fromDate;

    @NotNull(message="To date should not be null")
    @Column(name = "to_date", nullable = false)
    private Date toDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private StatusType status;

    @Column(name = "cancellation", columnDefinition = "boolean default false")
    private Boolean cancellation;

    @Column(name = "amendments", columnDefinition = "boolean default false")
    private Boolean amendments;

    @Column(name = "theft_protection", columnDefinition = "boolean default false")
    private Boolean theftProtection;

    @Column(name = "collision_damage", columnDefinition = "boolean default false")
    private Boolean collisionDamage;

    @Column(name = "full_insurance", columnDefinition = "boolean default false")
    private Boolean fullInsurance;

    @Column(name = "additional_driver", columnDefinition = "boolean default false")
    private Boolean additionalDriver;

    @NotBlank(message="Price can not be blank")
    @Column(name = "price", nullable = false)
    private Integer price;

    @Column(name = "cancel_request", columnDefinition = "boolean default false")
    private Boolean cancelRequest;
    
    @Column(name="car_dealer", insertable=false, updatable=false)
	private Integer carDealer;
	
	@NotNull(message="Car dealer should not be null")
	@ManyToOne
	@JoinColumn(name = "id", nullable = false)
	private CarDealer carDeal;

    @Column(name="user_id", insertable=false, updatable=false)
	private Integer userId;
	
    @NotNull(message="User should not be null")
    @ManyToOne
    @JoinColumn(name = "user_id",referencedColumnName="id", nullable = false)
    private User user;
    
    @Column(name="car_id", insertable=false, updatable=false)
	private Integer carId;

    @NotNull(message="Car should not be null")
    @ManyToOne
    @JoinColumn(name = "car_id",referencedColumnName="id", nullable = false)
    private Car car;
    
    @Column(name="address_id", insertable=false, updatable=false)
	private Integer addressId;

    @NotNull(message="Address should not be null")
    @ManyToOne
    @JoinColumn(name = "address_id", referencedColumnName="id",nullable = false)
    private Address address;

    
    
}
