package com.cts.thundercars.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.thundercars.entity.Roles;

public interface RolesRepository extends JpaRepository<Roles, Integer>{

}
