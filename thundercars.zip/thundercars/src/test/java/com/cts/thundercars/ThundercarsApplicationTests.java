package com.cts.thundercars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThundercarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
