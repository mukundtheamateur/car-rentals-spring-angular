package com.cts.thundercars.constant;

public enum FuelPolicyType {
	AlreadyFilled,
	FreeTank
}
