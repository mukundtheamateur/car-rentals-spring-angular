package com.cts.thundercars.constant;

public enum GearBoxType {
	Manual,
	Automatic
}
