package com.cts.thundercars.config;
public class Secret {
 
	public static String SECRET_KEY = "whfdgdcv784564379ehnsngddysdkdysujhAKHSGUSBHJjsasazjkcdhfuiesdhsjd";
	public static long EXPIRATION_TIME = 1800000; // 1 hour
}