package com.cts.thundercars.constant;

public enum FuelType {
	Diesel,
	Petrol,
	ElectricVehicle
}
