package com.cts.thundercars.constant;

public enum StatusType {
	paid, unpaid, reserved, cancelled
}
